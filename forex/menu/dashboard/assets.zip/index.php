<?php 
include('conn.php');
include('session.php');
header("Location: dashboard.php");
?>