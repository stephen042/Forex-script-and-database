 <!-- Favicons
    ================================================== -->
<link rel="shortcut icon" type="image/png" sizes="32x32" href="assets/img/favicon.png">
<link rel="shortcut icon" type="image/png" sizes="16x16" href="assets/img/favicon.png">

<link rel="canonical" href="dashboard">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1">

<link href="assets/css/css.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="assets/inner.css">
<link rel="stylesheet" type="text/css" href="assets/app.css">
<link rel="stylesheet" type="text/css" href="assets/cs.css">
<link rel="stylesheet" href="assets/css/sweetalert.min.js">
<link rel="stylesheet" href="assets/css/sweet-alert.css">
<script src="https://use.fontawesome.com/4b789087e7.js"></script>