<footer class="footer" style="height:auto">
        <div class="row clearfix">
           
<div class="bf-dark" style="vertical-align:text-top; height:auto; padding-bottom:20px">
        <div class="wrap">
		<DIV style="font-weight:bold; padding:5px 10px; font-size:0.9em">
            <div class="float-left">
            	
            		<!--googleoff: all-->
                	<A href="../contact.php" target="_blank">Support</A>
					<SPAN> | </SPAN><A href="../#privacy.php" target="_blank">Privacy 
policy</A>
                	<!--googleon: all-->
               
            </div>
            <div class="float-right">
               <a href="#https://api.whatsapp.com/send?phone=12024642514&text=GBTrader" target="_blank" style="color:inherit"><i class="fa fa-whatsapp"></i>&nbsp;+33 (758) 959 547</a><br />
<i class="fa fa-map-marker"></i>&nbsp; (www.providusoption.com/en) is regulated by the Cyprus Securities and Exchange Commission with CIF license number 185/12, licensed by the Financial Sector Conduct Authority (FSCA) of South Africa, with FSP No. 46614. 
<br />
<i class="fa fa-map-marker"></i>&nbsp;The company is also registered with the Financial Conduct Authority of the UK with number 600475.<br />
&copy; 2020. Providus Option. All rights reserved
            </div>
</DIV></div></div>
        </div>
		<script type="text/javascript" src="assets/js/sweet-alert.js"></script>	
		<?php

include("javascript.php");
?>
    </footer>